nome = 'Raíssa Aparecida de Paula Silva'
print('Meu nome é {} '.format(nome))
minusculo = nome.lower()
maiusculo = nome.upper()
print('Nome em maiusculo: {}'.format(maiusculo))
print('Nome em minusculo: {}'.format(minusculo))
print('Total de letras do meu nome: {}'.format(len(nome)))
print('Troca do sobrenome por Inatel: {}'.format(nome.replace('Silva','Inatel')))