sexo = input('Qual seu sexo, M ou F? ').upper()

while sexo != 'M' and sexo != 'F':
    sexo = input('Entrada inválida! Digite M ou F: ').upper()

print('Bem-vindo ao sistema ☺')
